import java.util.Random;
abstract class Compartment {
    public abstract String notice();
}
class FirstClass extends Compartment {
    @Override
    public String notice() {
        return "First Class Compartment - Travel Comfortably!";
    }
}
class Ladies extends Compartment {
    @Override
    public String notice() {
        return "Ladies Compartment - Reserved for Women.";
    }
}
class General extends Compartment {
    @Override
    public String notice() {
        return "General Compartment - Open for All Passengers.";
    }
}
class Luggage extends Compartment {
    @Override
    public String notice() {
        return "Luggage Compartment - Goods and Luggage Only.";
    }
}
public class TestCompartment {
    public static void main(String[] args) {

        Compartment[] compartments = new Compartment[10];
        Random random = new Random();

        for (int i = 0; i < compartments.length; i++) {

            int choice = random.nextInt(4) + 1; // Random number between 1 and 4

            switch (choice) {
                case 1:
                    compartments[i] = new FirstClass();
                    break;
                case 2:
                    compartments[i] = new Ladies();
                    break;
                case 3:
                    compartments[i] = new General();
                    break;
                case 4:
                    compartments[i] = new Luggage();
                    break;
            }

            System.out.println("Compartment " + (i + 1) + ": " + compartments[i].notice());
        }
    }
}